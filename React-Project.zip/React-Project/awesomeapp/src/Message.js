import React, { Component } from 'react';
import Person from './Person';

class Message extends Component{
    constructor(){
        super();
        this.state = {
            message : 'Welcome to Visitor',
            bgcolor : '#b9b995',
            show : true,
        }
        console.warn('constructor call');
    }

    changeMessage(){      
        this.setState({
            message : 'Thanks for Subscribe',
            bgcolor : "yellow"
        });
    } 
    
    toggleTitle(){      
        this.setState({
            show : !this.state.show
        });
    } 

    clickAlert(){      
        alert('Welcome');
    } 

    state1 = {
        person: [
            {name: 'sam',age: 25 },
            {name: 'Amy',age: 26 },
        ]
    }
    
    render(){
        console.warn('render call');
        return(
            <>
                <div className="msg_div" style={{backgroundColor:this.state.bgcolor}}>
                {this.state.show?
                <h4>{this.state.message}</h4>:null
                }
                <button className="button" onClick={() => this.clickAlert() }>Click Here</button>
                <button className="button" onClick={() => this.toggleTitle() }>Hide Show</button>
                <Person name={this.state1.person[0].name} age={this.state1.person[0].age} />
                <Person name={this.state1.person[1].name} age={this.state1.person[1].age} />
                <button className="button" onClick={() => this.changeMessage()}>Subscribe</button>                 
                </div>
            </>
        );
    }
}

export default Message;