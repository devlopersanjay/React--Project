import React, { useReducer, useState } from "react";

const MyUseReducer = () =>{

    //const [count,setCount] = useState(0);
    const initialState = 0;
    const reducer = (state,action) => {
        if(action.type=="increase"){
            return state+1;
        }
        if(action.type=="descrease"){
            return state-1;
        }
    }

    const [state, dispatch] = useReducer(reducer, initialState);

    return (
        <>
            <h1>Hello Reducer</h1>
            <button className="btn btn-primary sm m-3" onClick={() => dispatch({type: "increase"}) }>+</button>
            <label>{state}</label>
            <button className="btn btn-primary sm m-3" onClick={() => dispatch({type: "descrease"}) }>-</button>
        </>
    )
}

export default MyUseReducer;