import React from 'react';

const Person = (props) => {
    return (
        <div>
            <h1>Name : {props.name}, Age: {props.age}</h1>            
            {props.children}
        </div>
    );
}

export default Person;