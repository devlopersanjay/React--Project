import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import axios from "axios";
import Spinner from "./Spinner";
import '../App.css';
import InfiniteScroll from "react-infinite-scroll-component";


const Dashboard = () => {
  const [authusertoken, setauthusertoken] = useState(localStorage.getItem("authusertoken") || null);
  //console.log(authusertoken);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalResults, setTotalResults] = useState(0)

  const fetchData = async () => {
    console.log('---------fetchData------------------');    
    try {
      const resp = await axios.get(`https://jsonplaceholder.typicode.com/comments?_page=${page}&_limit=50`);
      setLoading(true);      
      //console.log(resp.data);
      setItems(resp.data);
      totalRecords();
      setLoading(false);
    } catch (err) {
        console.error(err);
    } 
  };

    const totalRecords = async () => {
      console.log('---------totalRecords------------------');
      try {
        const resp = await axios.get('https://jsonplaceholder.typicode.com/comments');
        //console.log(resp.data);
        setTotalResults(resp.data);
      }catch(err){
        console.error(err);
      }
    }

    useEffect(() => {
      //const isLogin = localStorage.getItem("authusertoken") || null;
      fetchData()
    }, []);

    const fetchMoreData = async () =>{
      console.log('---------fetchMoreData------------------');
      try {
        const resp = await axios.get(`https://jsonplaceholder.typicode.com/comments?_page=${page+1}&_limit=50`);
        setLoading(true);
        setPage(page+1)
        setItems(items.concat(resp.data));
        totalRecords();
        setLoading(false);
      } catch (err) {
          console.error(err);
      } 
    }

    if (!authusertoken) {
      return <Navigate replace to="/" />;
    } else {
    return (
      <>
        <div className="dashboard-box">
            <div className='container'>
              <div className="row">
                <div className="col-md-2"></div>
                  <div className="col-md-8">
                    <div className="row">
                      <div className="col-sm-6">
                        <h3>Comment List</h3>
                      </div>
                      <div className="col-sm-6 searchbox">
                      <input type="text" name="searchkey" placeholder="Search .... " />
                      {/* <button 
                          className="btn btn-md primary"
                          onClick={logoutUser}>
                          Logout</button> */}
                      </div>
                    </div>  
                    <InfiniteScroll
                      dataLength={items.length}
                      next={fetchMoreData}
                      hasMore={items.length !== totalResults}
                      loader={<Spinner />}>                    
                    <table id="users" className="table table-dark">
                      <thead>
                      <tr>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Content</th>                    
                      </tr>
                      </thead>
                      <tbody>
                      {items.map((item, i) => (
                      <tr key={i}>
                        <td>{item.name}</td>
                        <td>{item.email}</td>
                        <td>{item.body}</td>
                      </tr>
                      ))}
                      </tbody>
                    </table>
                    </InfiniteScroll>
                    {loading && <Spinner />}
                  </div>
                <div className="col-md-2"></div>
            </div>
          </div>
        </div>
      </>
    );
    }
};
export default Dashboard;