import React from "react";

const Spinner = ()=>{
    return(
        <div className="text-center" style={{color : "white"}}>Loading...</div>
    );
}

export default Spinner;