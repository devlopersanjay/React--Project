import React,{useRef} from 'react'
import MyFWref from './MyFWref';

function App() {
  let inputRef=useRef(null);
  function controlInput()
  {
    inputRef.current.style.color="red"
    //inputRef.current.style.display="none"
    inputRef.current.focus()
  }
  return (
    <div className="App">
      {/* <h1>useRef in React </h1> */}
      {/* <input className='form-control' type="text" ref={inputRef} /> */}
      <MyFWref ref={inputRef}/>
      <button onClick={controlInput}>Handle Input</button>
    </div>
  );

}

export default App;