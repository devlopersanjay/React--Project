import React, {Component} from 'react';

class Formdemo extends Component{

    constructor(){
        super()
        this.state={
            name:"Welcome",
            submitMsg:"",
            password:"",
            nameError:"",
            passError:"",
            users:null
        }
    }
    
    componentDidMount(){
        fetch('https://reqres.in/api/users').then((resp)=>{
            resp.json().then((result)=>{
                console.warn(result.data);
                this.setState({users:result.data})
            });
        })
    }

    valid(){
        if(!this.state.name.includes("@") && this.state.password.length < 5 ){
            this.setState({
                nameError : "Invalid Name",
                passError : "Password length should be more than 5"
            });
        }else if(!this.state.name.includes("@")){
            this.setState({
                nameError : "Invalid Name"
            });
        }else if(this.state.password.length < 5 ){
            this.setState({
                passError : "Password length should be more than 5"
            });
        }else{
            return true;
        }
    }

    btnSubmit = () =>{
        this.setState({
            nameError : "",
            passError : ""
        });
        if(this.valid()){
            alert("Form has been submited.");
        }
    }

    onChangeHandler = (e , isValid) => {
        console.log(e);
        let _name = e.target.name;
        let _value = e.target.value;
        this.setState({ _name: _value });

    }
    render(){
        return(
            <div class="container py-3">
                <div className="msg_div">
                    <h3>Form Validation {this.state.submitMsg}</h3>
                    <div class="form-group">
                        <label for="uname1">Username</label>
                        <input type="text" placeholder="Enter FirstName" name="name" className="form-control"
                        onChange={(e)=>{this.setState({name:e.target.value})}} />
                        <p style={{ color : "red" , fontsize : "14px", fontWeight : 900 }}>{this.state.nameError}</p>
                    </div>
                    <div class="form-group">
                        <label for="uname1">password</label>
                        <input type="password" placeholder="Enter password" name="password" className="form-control"
                        onChange={
                        (e) => this.onChangeHandler(e , true)
                        }/>
                        <p style={{color: "red" , fontsize : "14px" , fontWeight : 900  }}>{this.state.passError}</p>
                    </div>
                    <button className="btn btn-primary my-3" onClick={() => this.btnSubmit()} >Sign In</button>
                    <table class="table table-bordered red-border text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.users ?
                            this.state.users.map((item,i)=>
                            <tr>
                            <th scope="row">{item.id}</th>
                            <th>{item.first_name}</th>
                            <th>{item.last_name}</th>
                            <th>{item.email}</th></tr>
                            )
                            :
                            null
                        }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

}

export default Formdemo;