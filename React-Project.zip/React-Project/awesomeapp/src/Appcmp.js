import React, { Component } from 'react';
import User from './Usercmp';

class Appcmp extends Component{

    constructor(){
        super();
        this.state={
            active:null,
            toggle:true,
            who:null
        }
    }

    componentDidUpdate(){
        console.warn('componentDidUpdate');
        if(this.state.who==null){
            this.setState({
                who:'John doe'        
            })
        }
    }

    render(){
        return(
            <div className="alert alert-primary" role="alert">
                <b>Is Component Did update ? {this.state.active} {this.state.who}</b>
                <button className="button" onClick={()=>{this.setState({active:'yes'})}}> Click Here</button>

                <b>Component Will Unmount User Data</b>
                {
                    this.state.toggle?<User/>:null
                }
                <button className="button" onClick={()=>{this.setState({toggle:!this.state.toggle})}} > Delete User</button>
            </div>
        )
    }
}

export default Appcmp;