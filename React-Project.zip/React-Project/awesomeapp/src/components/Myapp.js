import React from "react";
//import MyuseState from "./MyuseState";
//import MyPurecommp from "./MyPureComp";
import MyRouter from './MyRouter';
//import MyRef from "./MyRef";

const Myapp = () =>{

    return (
        <>
            {/* <MyuseState /> */}
            {/* <MyPurecommp /> */}
            <MyRouter />
            {/* <MyRef /> */}
        </>
    );

}

export default Myapp;