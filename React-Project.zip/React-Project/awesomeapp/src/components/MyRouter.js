import React from 'react'
import { BrowserRouter as Router, Link, Route,Switch } from 'react-router-dom'
import MyHome from './MyHome';
import MyEmpForm from './MyEmpForm';
import MyLogin from './MyLogin';
import MyUseReducer from './MyUseReducer';


function MyRouter() {
  return (
    <>
      <Router>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <a className="navbar-brand" href="#">Navbar</a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item active">
                <Link className="nav-link" to="/" >Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/about" >About</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/add" >Employee</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/reducercount" >CounterApp</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/login" >Login</Link>
              </li>
            </ul>
          </div>
        </nav>

        <Switch >
        <Route path="/" exact={true}><MyHome /></Route>
        <Route path="/about"><About /></Route>
        <Route path="/login"><MyLogin /></Route>
        <Route path="/add"><MyEmpForm /></Route>
        <Route path="/reducercount"><MyUseReducer /></Route>
        <Route path="*"><PageNotFound /></Route>
        </Switch>
      </Router>
    </>
  );
}

function About() {
  return (<div>
    <h1>About Page</h1>
    <p>This is About Page</p>
  </div>)
}
function PageNotFound() {
  return (<div>
    <h1>404 Page</h1>
    <p>This is Not found</p>
  </div>)
}

export default MyRouter;




