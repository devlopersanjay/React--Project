import React from 'react';

const  Gridbox = (props) => {

    return(
        <div className="card" style={{width: '18rem' }}>
            <img src={props.grid_image} className="card-img-top" alt="..." />
            <div className="card-body">
            <a href={props.grid_link} ><h5 className="card-title">{props.grid_title}</h5></a>
                <p className="card-text">{props.grid_desc}</p>
            </div>
        </div>
    );
    
}

export default Gridbox;