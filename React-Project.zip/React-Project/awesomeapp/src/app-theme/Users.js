import React from "react";
import Students from '../arraydata';
import { Component } from "react";
import Userdata from "../Gallery";
import Gridbox from "../Gridbox";

// const Userlist = () =>{
//     return(
//         <table className="table table-dark">
//         <thead>
//             <tr>
//             <th scope="col">#</th>
//             <th scope="col">Name</th>
//             <th scope="col">Age</th>
//             <th scope="col">Quali</th>
//             </tr>
//         </thead>
//         <tbody>
//             {Students.map((val,i) =>  {
//                 return (<Userdata 
//                     key={i+1}
//                     name={val.name}
//                     age={val.age}
//                     qualification={val.qualification}
//                 />);
//             }   )}
//         </tbody> 
//         </table>    
               
//     );
// } 

class Userlist extends Component{
    constructor(){
        super();
        this.state = {
            users:[
              {uid:11, name:'John', age:20, degree:'Mcs'},
              {uid:12, name:'Jill', age:30, degree:'Mca'},
              {uid:13, name:'Peter', age:40, degree:'Msc'},
            ]
          };
    
        console.log(this.state)
    }
    

    delUser = (i,e)=>{
        console.log(i);
        const users = Object.assign([], this.state.users);
        users.splice(i, 1);
        this.setState({users:users});
    }

    render(){

        return (
        <>
        <table className="table table-dark">
        <thead>             
            <tr>
            <th scope="col">Action</th>
            <th scope="col">Name</th>
            <th scope="col">Age</th>
            <th scope="col">Quali</th>
            </tr>
        </thead>
        <tbody>
            {this.state.users.map((val,i) =>  {
                return (<Userdata
                    delEvent={this.delUser.bind(this,i)}
                    key={val.uid}
                    name={val.name}
                    age={val.age}
                    degree={val.degree}
                />);
            }   )}
        </tbody> 
        </table>
        <div className="row">
            <Gridbox grid_image="https://www.w3schools.com/bootstrap/paris.jpg" 
            grid_title="Blog 1" 
            grid_link="https://reactrouter.com/" 
            grid_desc="Lorem ipsum donec id elit non mi porta gravida at eget metus."/>
            <Gridbox grid_image="https://www.w3schools.com/bootstrap/sanfran.jpg" 
            grid_title="Blog 2" 
            grid_link="https://reactrouter.com/" 
            grid_desc="Lorem ipsum donec id elit non mi porta gravida at eget metus."/>
            <Gridbox grid_image="https://www.w3schools.com/bootstrap/paris.jpg" 
            grid_title="Blog 3" 
            grid_link="https://reactrouter.com/" 
            grid_desc="Lorem ipsum donec id elit non mi porta gravida at eget metus."/>
        </div> 
        </>
        )
      }
}

export default Userlist;