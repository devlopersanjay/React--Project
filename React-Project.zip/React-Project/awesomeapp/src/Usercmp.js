import React, { Component } from 'react';

export default class User extends Component{
    componentWillUnmount(){
        alert('User has deleted.');
    }
    render(){
        return(
            <div className="alert alert-primary" role="alert">
                <ul>
                    <li>Name : John Doe</li>
                    <li>Email : johndoe@gmail.com</li>
                    <li>Age : 27</li>
                </ul>
            </div>
        )
    }
}
