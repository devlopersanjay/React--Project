import { useState } from "react";

export default function UserForm() {

  const [contactInfo, setContactInfo] = useState({
    username: "",
    email: "",
    phonenumber: "",
  });

  const [errors, setErrors] = useState({});
  const validateInfo = (event, fieldname, value) => {
    console.log(fieldname);
    console.log(value);

    switch (fieldname) {
        case 'username':
          if (value.length <= 4) {
              setErrors({
                  ...errors,
                  username: 'Username atleast have 5 letters'
              })
          } else {
              setErrors({errors:{}});
          }
        break;
        case 'email':
            if(!new RegExp(/^[a-zA-Z0-9]+@+[a-zA-Z0-9]+.+[A-z]/).test(value)){
                setErrors({
                    ...errors,
                    email:'Email is not @valid'
                })
            }else{
               setErrors({errors:{}});              
            }
        break;
        case 'phonenumber':
          if (value.length <= 4) {
              setErrors({
                  ...errors,
                  phonenumber: 'phonenumber have 10 letters'
              })
          } else {
              setErrors({errors:{}});
          }
        break;
        default:
        break;
    }
  }

  const handleChange = (event) => {
    let fieldname = event.target.name;
    let fieldval = event.target.value;
    validateInfo(event,fieldname,fieldval);   
    setContactInfo({ ...contactInfo, [event.target.name]: event.target.value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(JSON.stringify(contactInfo));
    setContactInfo({ username: "", email: "", phonenumber: "" });
  };

  return (

    <div className='container'>
      <div className="row">
          <p>{JSON.stringify(contactInfo)}</p>
          <form onSubmit={handleSubmit}>
              <h3>Contact Form</h3>
              <div  className="mb-3">
              <input
                  type="text"
                  name="username"
                  placeholder="Name"
                  className="form-control"
                  value={contactInfo.username}
                  onChange={handleChange}
              />
              {errors.username && <span style={{color:"red"}}>{errors.username}</span>}
              </div>
              <div  className="mb-3">
              <input
                  type="text"
                  name="email"
                  placeholder="Email"
                  className="form-control"
                  value={contactInfo.email}
                  onChange={handleChange}
              />
              {errors.email && <span style={{color:"red"}}>{errors.email}</span>}
              </div>
              <div  className="mb-3">
              <input
                  type="number"
                  name="phonenumber"
                  placeholder="Phone Number"
                  className="form-control"
                  value={contactInfo.phonenumber}
                  onChange={handleChange}
              />
              {errors.phonenumber && <span style={{color:"red"}}>{errors.phonenumber}</span>}
              </div>
              <div  className="mb-3">
              <button className="btn btn-primary">Submit Contact</button>
              </div>
          </form>
      </div>         
    </div>
  );
}