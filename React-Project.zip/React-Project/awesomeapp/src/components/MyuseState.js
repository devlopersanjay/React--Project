import React, { Component ,useState } from 'react';
import ReactDom from 'react-dom';
import Students from '../arraydata';
import Myprops from './Myprops';

// class MyuseState extends Component {
//     constructor() {
//       super();
//       this.state = {
//         name: "Friend"
//       };
//     }

//     setname(){
//         this.setState({
//             name:"sanjay"
//         })
//     }

//     render(){
//         return(
//             <>
//                 <h2>Hello {this.state.name}</h2>
//                 <button onClick={()=> this.setname()}>Click Me</button>
//                 <ul>
//                 {Students.map((val,i) =>  {
//                     return (<Myprops 
//                         key={i+1}
//                         name={val.name}
//                         age={val.age}
//                         qualification={val.qualification}
//                     />);
//                 }   )} 
//                 </ul>
//             </>
//         )
//     }
// }    

const MyuseState = () => {

const [name,setName] = useState('Friends');

    return(
         <>
            <h2>Hello {name}</h2>
                <ul>
                {Students.map((val,i) =>  {
                    return (<Myprops 
                        key={i+1}
                        name={val.name}
                        age={val.age}
                        qualification={val.qualification}
                    />);
                    }   
                )} 
                </ul>
            <button onClick={()=>{ setName('Sanjay'); }}>Click Me</button>
       </>
    )
}

export default MyuseState;
