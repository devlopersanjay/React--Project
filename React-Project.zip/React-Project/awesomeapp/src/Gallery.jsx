import React from 'react';
import Heading from './Heading';

function Userdata(props){
    return (
        <tr>
        <td><input onChange={props.changeEvent} value={props.children}/><button className="btn btn-danger" onClick={props.delEvent}>X</button></td>
        <td>{props.name}</td>
        <td>{props.age}</td>
        <td>{props.degree}</td>        
        </tr>
    );
}

// function Gallery(props){
//     return (
//         <article className="col-sm">
//             <a className="location-title" href={props.link}>
//             {props.title}</a>
//             <div className="location-image">
//                 <a href={props.link}>
//                 <img width="300" height="169" src={props.imgsrc} alt="san francisco" />    
//             </a>            
//             </div>
//             <h5><b>{props.title}</b></h5>
//         </article>
//     );
// }



//export default Gallery;
export default Userdata;