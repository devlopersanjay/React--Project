import React,{ useState } from "react";

const MyEmpForm = () => {

    const [empInfo, setEmpInfo] = useState({
        emp_name: "",
        emp_age: "",
        emp_email: "",
    });
    
    const [errors, setErrors] = useState({});

    const  validError = () =>{
        console.log(empInfo);
        // if(!emp_name && emp_name.length < 5 ){
        //     setErrors({
        //         ...errors,
        //         nameError:'Username atleast have 5 letters'
        //     })
        // }else if(!emp_email){
        //     setErrors({
        //         ...errors,
        //         cityNameError:'Invalid city'
        //     })
        // }else if(emp_email.includes("@")){
        //     setErrors({
        //         ...errors,
        //         cityError:'Invalid Email id inlcude @'
        //     })    
        // }else if(!emp_age){
        //     setErrors({
        //         ...errors,
        //         ageError:"Enter Age value"
        //     })
        // }else{
        //     setErrors({
        //         ...errors,
        //         nameError:'',
        //         cityError:'',
        //         ageError:''
        //     })
        // }
    }

    const handleChange = (e) =>{
       const {name,value} = e.target;       
       setEmpInfo({
            ...empInfo,[name]:value
       });
    }

    const saveData = () => {
        validError();
    }

    return(
        <>
            <div className="container">
                <div className="row">
                    <h1>Register</h1>
                    <div className="mb-3">
                        <input type="text" className="form-control" id="name" name="name"
                        value={empInfo.emp_name} onChange={handleChange} placeholder="Name" />
                    </div>
                    <div className="mb-3">
                        <input type="text" className="form-control" id="age" name="age"
                        value={empInfo.emp_age} onChange={handleChange} placeholder="Age" />
                    </div>
                    <div className="mb-3">
                        <input type="text" className="form-control" id="email" name="email"
                        value={empInfo.emp_email} onChange={handleChange} placeholder="Email" />
                    </div>
                    <button type="button" className="btn btn-success btn-sm" onClick={saveData} >Save New User</button>
                </div>
            </div>
        </>
    )
}

export default MyEmpForm