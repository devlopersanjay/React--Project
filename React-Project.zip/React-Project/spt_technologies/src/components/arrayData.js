const arrData = [
    {
      "firstname": "sanjay",
      "lastname": "ratnani",
      "username": "sanjay",
      "password": "123456",
      "email": "sanjay@ratnani.in",
    },
    {
      "firstname": "Hardik",
      "lastname": "Patel",
      "username": "hardik",
      "password": "123456",
      "email": "hardik@patel.com",      
    }
  ];

export default arrData;