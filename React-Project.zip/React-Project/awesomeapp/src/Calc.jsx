const youtuber = "Calculater"; 
const subs = "React JS Subscriber"; 


function add(fno,sno){
    return (fno+sno);
}

function sub(fno,sno){
    return (fno-sno);
}

function mul(fno,sno){
    return (fno*sno);
}

function div(fno,sno){
    return (fno/sno);
}

export default youtuber;
export {subs, add, sub, mul, div};
