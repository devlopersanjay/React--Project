import React from 'react';

const fname = "Sanjay";
const lname = "Ratnani";
const introduce = "I am web developer.";
const companyName = "In Dynamic Dreamz. At Surat Gujarat. ";
const currentDate = new Date().toLocaleDateString();
const currentTime = new Date().toLocaleTimeString();
const title_h4 = {
    padding: '15px',
    textAlign: 'center',
    fontFamily: '"Josefin Sans", sans-serif'
}

function Heading(props){
    return (
        <>
        <h1>{props.name}</h1> 
        </>
    )
}

function Short_desc(){
    return (
    <>
    <h1 className="heading">My name is {fname} {lname} </h1>
    <h3 className="heading"> {introduce+' '+companyName} </h3>
    <h4 style={title_h4}> {`Hello My name is ${fname} and lname ${lname}`}</h4>
    <p>{`current Date is ${currentDate} current time is  ${currentTime} `}</p>
    </>)
}

export default Heading;
export {Short_desc};