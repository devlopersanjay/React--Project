import React,{Component} from "react";

// class Myprops extends Component{

//     constructor(){
//         super();
//     }

//     render(){
//         return(
//             <li>{this.props.name} is {this.props.age} years old</li>
//         )
//     }
// }

const Myprops = (props) => {
    console.log(props);
    const {name,age,qualification} = props
    return(
        <li>{name} is {age} years old. They Qualified with {qualification}</li>
    )
}

export default Myprops;