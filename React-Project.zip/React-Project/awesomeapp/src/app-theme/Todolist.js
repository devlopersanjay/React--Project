import React,{ useState } from "react";

const Todolist = () => {

    let [inputList,setInputList] = useState("");
    let [Items,setItems] = useState([]);  

    const inputEvent = (event) => {
        setInputList(event.target.value);
    }

    const btnAddClick = () => {
        setItems((oldItems) => {
            return [...oldItems, inputList];
        })
        setInputList('');
    }

    const btnDelClick = (id) => {
        console.log('deleted');
        setItems((oldItems) => {
            return oldItems.filter((arrElem,index)=>{
                return index !== id;
            });
        })
    }

    return (
        <>
            <div className="header">
                <h2>My To Do List</h2>
                <input type="text" placeholder="Title..." value={inputList} onChange={inputEvent}/>
                <span className="addBtn" onClick={btnAddClick}>Add</span>
                {inputList}
            </div>
            <ul id="myUL" className="todolist">
                {Items.map((itemval, i) => {
                    return  <>
                        <li> {itemval} <span className="close" onClick={() => {
                            btnDelClick(i);
                        } }>×</span></li>
                         </>
                })}
            </ul>
        </>
    );
}

export default Todolist;