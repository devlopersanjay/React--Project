import React, { useEffect, useState } from 'react'
const MyHome = () => {

  const [data,setData] = useState([]);
  const [id,setId] = useState("");
  const [name,setName] = useState("");
  const [age,setAge] = useState("");
  const [city,setCity] = useState("");
  const [s_key,setSkey] = useState("");


  // const [dataval,setDataVal] = useState({
  //   id: '',
  //   name: '',
  //   age:'',
  //   city:'',
  //   s_key:''
  // })
  
  //   const  onChangeHandle = (e) => {
  //     let name  = e.target.name;
  //     let value  = e.target.value;
  //     setDataVal({
  //       ...dataval,[name]:value
  //     })

  //    }

  const apiOnload = () =>{
    setName("");
    setAge("");
    setCity("");
    setId("");

    fetch('http://localhost/php_rest_myblog/api-listall.php')
    .then((response) => response.json())
    .then((result) => setData(result))
    .catch((e) => console.warn(e) )
  }

  useEffect(()=>{
    console.log('call useEffect');
    apiOnload()
  },[]);

  const deleteUser = (id) => {
    console.log(id+'calll delete');
    fetch('/php_rest_myblog/api-delete.php', {
        method: 'DELETE',
        headers: { 'Content-type': 'application/json;'},
        body: JSON.stringify({id})
    }).then(response => response.json())
    .then((result) => {
      console.log(result);
      apiOnload()
    })
  }

  const selectUser = (user) =>{
    console.log(user);
    setName(user.name);
    setAge(user.age);
    setCity(user.city);
    setId(user.id);
  }


  const updateData = () =>{
    let userData = {id,name,age,city}
    let empData = {name,age,city};
    if(id != 0){
      fetch('/php_rest_myblog/api-update.php',{
          method: 'PUT',
          headers:{
            'Content-type': 'application/json;'
          },
        body: JSON.stringify(userData)
      })
      .then((response)=> {
        response.json()
       })  
      .then((result)=>{
        console.log('update call  response ', result);
        // if(res && res.status && res.status === 200){

        // }
        
        setId("");
        apiOnload()
      })
      .catch((err)=> console.log(err))
    }else{
      console.log('insert call');
      fetch('/php_rest_myblog/api-add.php',{
        method : 'POST',
        headers: {
            'Content-type': 'application/json;'
        },
        body: JSON.stringify(empData),
      })
      .then((response) => {
        response.json()
      })
      .then((result) =>{
        console.log('insert call');
        apiOnload()})
      .catch((err)=> console.log(err));
    }
  }

  const searchData = () =>{
    fetch(`http://localhost/php_rest_myblog/api-search.php?search=${s_key}`)
    .then((response) => response.json())
    .then((result) => setData(result))
    .catch((e) => console.warn(e) )
  } 

  const resetData = () =>{
    setSkey('');
    apiOnload()
  } 

  return (
      <div className='container'>
        <div className="row">
            <h1>Add New Employee</h1>
            <div className="mb-3">
                <input type="text" className="form-control" id="name" name="name"
                value={name} onChange={(e)=> setName(e.target.value) } placeholder="Name" />
            </div>
            <div className="mb-3">
                <input type="text" className="form-control" id="age" name="age"
                value={age} onChange={(e)=> setAge(e.target.value) } placeholder="Age" />
            </div>
            <div className="mb-3">
                <input type="text" className="form-control" id="city" name="city" value={city} 
                onChange={(e)=> setCity(e.target.value) } placeholder="city" />
            </div>
            <button type="button" className="btn btn-success btn-sm" onClick={updateData} >save User</button>
        </div>
        
        <div  className='row'>
          <div className="d-flex flex-row-reverse">
            <div className="p-2"><button type="button" className="btn btn-success btn-sm" 
            onClick={searchData} >Search</button>
            <button type="button" className="btn btn-info btn-sm mx-2" 
            onClick={resetData} >Reset</button></div>
            <div className="p-2">
                <input type="text" className="form-control" id="s_key" name="s_key" value={s_key} 
                onChange={(e)=> setSkey(e.target.value) } placeholder="Search..." /></div>
          </div>
        </div>
        <div className='row'>
          <h1>All Users lists </h1>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Age</th>
                <th scope="col">##</th>
              </tr>
            </thead>
            <tbody>
            { data.length ? data.map((user,i) => (
                <tr key={`user-${user.id}`}>
                  <th>{user.id}</th>
                  <th>{user.name}</th>
                  <th>{user.city}</th>
                  <th>{user.age}</th>
                  <th><button onClick={()=> selectUser(user, i) } className='btn btn-info btn-sm'>Edit</button>
                    | <button onClick={()=> deleteUser(user.id) } className='btn btn-danger btn-sm'>Delete</button></th>
                </tr>  
              )) 
            : "No Data Found" }  
            </tbody> 
           </table>
        </div>
    </div>
  );
}
export default MyHome;