

const Students = [
    {
        uid: 11,
        name:"Sanjay",
        age:"25",
        qualification:"MCA"
    },
    {
        uid: 12,
        name:"Ashish",
        age:"26",
        qualification:"BCA"
    },
    {
        uid: 13,
        name:"Kuldip",
        age:"27",
        qualification:"Army"
    }
];

// const Galleryarr = [
//     {
//         imgsrc:"https://wallpapercave.com/wp/wp2494538.jpg",
//         title:"Demo 1",
//         link:"https://picsum.photos/"
//     },
//     {
//         imgsrc:"https://wallpapercave.com/wp/wp6052375.jpg",
//         title:"Demo 2",
//         link:"https://picsum.photos/"
//     },
//     {
//         imgsrc:"https://wallpapercave.com/wp/wp3850825.jpg",
//         title:"Demo 3",
//         link:"https://picsum.photos/"
//     },
//     {
//         imgsrc:"https://wallpapercave.com/wp/wp2494539.jpg",
//         title:"Demo 4",
//         link:"https://picsum.photos/"
//     }
// ];

//export default Galleryarr;
export default Students;