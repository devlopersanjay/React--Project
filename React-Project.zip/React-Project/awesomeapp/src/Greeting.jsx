import React from 'react';



function Greeting (){
    let nowTime = new Date();
    nowTime = nowTime.getHours();
    let greeting = "";
    const headingColor = {};

    if(nowTime >= 1 && nowTime < 12 ){
        greeting = "Good Morning";
        headingColor.color = "green";
    }else if(nowTime >= 12 && nowTime < 19 ){
        greeting = "Good Afternoon";
        headingColor.color = "Orange";
    }else{
        greeting = "Good Night";
        headingColor.color = "Black";
    }    

    return(
        <h1>Hello! <span style={headingColor}>{greeting} </span></h1>
    );
}

export default Greeting;
