import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import axios from "axios";
import '../App.css';

const Dashboard = () => {
  const [authusertoken, setauthusertoken] = useState(localStorage.getItem("authusertoken") || null);
  console.log(authusertoken);
  const [countrylist, setCountrylist] = useState([]);

    useEffect(() => {
      const isLogin = localStorage.getItem("authusertoken") || null;
      console.log(isLogin);
      if (isLogin) {
          console.log('enter in');
          axios.get("https://restcountries.com/v2/all")
          .then((response) => setCountrylist(response.data))
          .catch((error) => console.log(error));
      }
  }, []);

    // const logoutUser = () => {
    //   localStorage.setItem("authusertoken",'');
    //   return <Navigate replace to="/" />;
    // }

    if (!authusertoken) {
      return <Navigate replace to="/" />;
    } else {
    return (
      <>
        <div className="dashboard-box">
            <div className='container'>
              <div className="row">
                <div className="col-md-2"></div>
                  <div className="col-md-8">
                    <div className="row">
                      <div className="col-sm-6">
                        <h3>Country List</h3>
                      </div>
                      <div className="col-sm-6 searchbox">
                      <input type="text" name="searchkey" placeholder="Search .... " />
                      {/* <button 
                          className="btn btn-md primary"
                          onClick={logoutUser}>
                          Logout</button> */}
                      </div>
                    </div>
                    <table id="users" className="table table-dark">
                      <thead>
                      <tr>
                          <th>Name</th>
                          <th>Capital</th>
                          <th>Subregion</th>                    
                      </tr>
                      </thead>
                      <tbody>
                      {countrylist.map((country, i) => (
                      <tr key={i}>
                        <td>{country.name}</td>
                        <td>{country.capital}</td>
                        <td>{country.subregion}</td>
                      </tr>
                      ))}
                      </tbody>
                    </table>
                  </div>
                <div className="col-md-2"></div>
            </div>
          </div>
        </div>
      </>
    );
    }
};
export default Dashboard;