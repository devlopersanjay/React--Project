import React,{forwardRef} from 'react'
function MyFWref(props,ref)
{
    return(
        <div>
            <h1>forwardRef</h1>
            <input  className='form-control' ref={ref} type="text" />
        </div>
    )
}

export default forwardRef(MyFWref);