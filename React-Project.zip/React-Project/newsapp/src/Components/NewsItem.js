import React from "react";

const NewsItem = (props) => {
    let {title,description,imageUrl,newsUrl,author,dateNews,source,color} = props;
    return(
        <div className="card">
            <div style={{right: '0' ,display: 'flex', justifyContent: 'flex-end', position: 'absolute'}}>
            <span className={`badge rounded-pill bg-${color}`}>{source}</span>
            </div>
            <img src={!imageUrl?"https://data1.ibtimes.co.in/en/full/766594/phone.png":imageUrl} className="card-img-top" alt="..." />
            <div className="card-body">
                <h5 className="card-title">{title}</h5>
                <p className="card-text">{description}</p>
                <p className="card-text">
                <small className="text-muted"><b>By</b> {author?author:'Unkonwn'} <b>On</b> {new Date(dateNews).toGMTString()}</small></p>
                <a href={newsUrl} target="_blank" className="btn btn-dark" rel="noreferrer">Read More</a>
            </div>
        </div>
    )
}
export default NewsItem;