import React from 'react';
import ReactDOM from 'react-dom';
//import './index.css';
import './app-theme/todo.css';
//import Navmenulink from './app-theme/Header';
//import AboutSection from './Appcontent';
import App,{Counterset,Helloform} from './App';
import Userlist from './app-theme/Users';
import Todolist from './app-theme/Todolist';
import Appcmp from './Appcmp';
import Message from './Message';
//import Formdemo from './Formvalidate';
import Myapp from './components/Myapp';

//import {Students} from './arraydata';

/*const newArr = Students.map((cval)=>{
    return (<b>My name is {cval.name}. i am {cval.age} old.</b>);
});*/

//ReactDOM.render(newArr,document.getElementById('showdata'));
// function Person(props){
//     console.log(props);
//     //inline csss
//     const span = {
//         color:'orange'
//     }
//     return (
//         <div>
//             <h1 >{props.name}</h1>
//             <p>Age is {props.age}</p>
//             <span className={span}>{props.children}</span>
//         </div>
//     );
// }

// let name={
//     firstname: "Sanjay",
//     lastname: "Ratnani",
    
// }

// let emp={
//     firstname: "Kuldip",
//     lastname: "Chauhan",
// }

// let dispFullname = function (city, state){
//     console.log(this.firstname+" "+this.lastname+" "+city+" "+state);
// }

// dispFullname.call(name,"Navsari","Gujarat");
// dispFullname.apply(emp,["Surat","Gujarat"]);
// let printMyname = dispFullname.bind(name,"Navsari","Gujarat");
// console.log(printMyname);
// printMyname();

// var app1 = (
//     <div><Person name="Max" age="24"/>
//     <p>inline css</p>
//     <Person name="Man" age="28"/></div>
// );
//ReactDOM.render(<AboutSection />,document.getElementById('apptheme') ); 
//ReactDOM.render(<Todolist />,document.getElementById('todo') ); 
//ReactDOM.render(<MyuseState />,document.getElementById('msg') ); 
//ReactDOM.render(<Helloform />,document.getElementById('msg') ); 
//ReactDOM.render(<Counterset />,document.getElementById('timeset') );  
//ReactDOM.render(<Userlist />,document.getElementById('timeset') ); 
 ReactDOM.render(<Myapp />,document.getElementById('app') );
// ReactDOM.render(<Appcmp />,document.getElementById('apptheme') );
// ReactDOM.render(<App></App>,document.getElementById('root') );
//ReactDOM.render(<Formdemo/>,document.getElementById('formvalidate') );



