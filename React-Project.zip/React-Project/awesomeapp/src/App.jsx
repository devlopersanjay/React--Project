import React, { useEffect, useState } from 'react';
import sdata from './arraydata';
import Gallery from './Gallery';
//import youtuber, {subs, add, sub, mul, div} from './Calc'; //or import * as list_const from './List';

const App = () =>{
    return(
        <div className="row">
            {sdata.map((val,i) =>  {
                return (<Gallery 
                    key={i+1}
                    imgsrc={val.imgsrc}
                    title={val.title}
                    link={val.link}
                />);
            }   )} 
        </div>        
    );
} 

const Counterset = () => {  
    //let cntState = useState(0);
    //console.log(cntState);
    const [count,setCount] = useState(0);
    const InCnt = () => {
        setCount(count+1);
    }    
    return(
        <>
        <div className="col-12">
            <h1>Counter {count}</h1>
            <button className="button"
            onClick={InCnt}>Click Me</button>           
        </div>
        </>
    );
} 
 
const  Helloform = () => {

    // const [fullName, setFullName] = useState({
    //     fname: "",
    //     lname: "",
    //     email: ""
    // });

    let stateObj = useState({
        fname: "",
        lname: "",
        email: ""
    });
    console.log(stateObj);
    let fullName = stateObj[0];
    let setFullName = stateObj[1];

    const inputEvent = (event) => {
      //  console.log(event);
        console.log(event.target.name , event.target.value);
        // console.log(event.target.name);

        //  { name, value} = event.target;
        let _name = event.target.name;
        let _value = event.target.value;

        setFullName((preValue) => {
            console.log('preValue' , preValue);
            let obj = {...preValue};
            console.log('obj before set ' , obj);
            obj[_name] = _value;
            console.log('obj after set ' , obj);
            return obj;
            // return {
            //     ...preValue,
            //     [name] : value,
            // }
        });

    }

    const onSubmits = (event) => {
        event.preventDefault();
        console.log(event);
    }

    // const [cnt,setCount]=useState(1);
    // useEffect(()=>{
    //     console.warn(cnt);
    // },[cnt==5])

    return(
        <>
        <div className="container"> 
            {/* <b>UseEffect is update {cnt}</b>
            <button className="button" onClick={()=>setCount(cnt+1)}>Click here</button> */}
            <form onSubmit={onSubmits}>
                <h1>Welocme <br/>{fullName.fname} {fullName.lname} </h1>
                <h3>{fullName.email}</h3>
                <div className="mb-3">
                <label className="form-label">First Name</label>
                <input 
                type="text" 
                placeholder="Enter FirstName"
                className="form-control" 
                name="fname" 
                onChange={inputEvent} 
                value={fullName.fname}/>
                </div>
                <div className="mb-3">
                <label className="form-label">Last Name</label>
                <input 
                type="text" 
                placeholder="Enter Last Name" 
                className="form-control"
                name="lname" 
                onChange={inputEvent} 
                value={fullName.lname}/>
                </div>
                <div className="mb-3">
                <label className="form-label">Email</label>
                <input type="text" 
                placeholder="Enter email" 
                name="email" 
                className="form-control" 
                onChange={inputEvent} 
                value={fullName.email}/>
                    </div>
                <div className="mb-3">
                <button className="button"
                onClick={onSubmits}>Submit</button>
                </div>
            </form>
        </div>
        </>
    );    
}

export default App;
export {Counterset,Helloform};